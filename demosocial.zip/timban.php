<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chào mừng bạn đến với MXH</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <link rel="stylesheet" href="style/hieuung.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
</head>
<body>


  <div class="_big">
        <div class="_left">
            <div class="_adv">
                <span class="fa fa-search">
                </span>
                <span>Theo dõi những sở thích của bạn</span>
            </div>
            <div class="_adv">
                 <span class="fa fa-search-plus">
                </span>
                <span>Kết bạn bốn phương.</span>
            </div>
            <div class="_adv">
                <span class="fa fa-comment">
                </span>
                <span>Tham gia vào cuộc trò chuyện.</span>
            </div>
        </div>
        <div class="_right">
            
            <div class="_right1">
                <div class="_top">
                    <span>Tham gia cùng với chúng tôi NGAY BÂY GIỜ!</span>
                    <div>
            <form action = " searchusername.php" method = "GET" >
<div class="form-group">
 <small><small> <label for="search">Tìm Kiếm User</label></small>
  <input type="text" class="form-control" id="tukhoa1" name = "tukhoa1" placeholder="Tìm Thành Viên" >

</div>    

<button type="submit" class="btn btn-primary">Tìm Kiếm</button>
</form>
            </div>

                <!-- </div>
                <a href="singup.php">
                    <div class="_button" style="background-color: #1da1f2;"> Sing up</div>
                </a>
                <a href="login.php">  
                    <div class="_button" style="color: #1da1f2"> Log in</div>
                </a> -->
            </div>
        </div>
    </div>
</body>
</html>